<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Minimal Form Interface</title>
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="author" content="" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="shortcut icon" href="../favicon.ico">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/normalize.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/demosign.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fonts/font-awesome-4.2.0/css/font-awesome.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/menu_topside.css')); ?>" />
    <script src="<?php echo e(asset('js/modernizr.custom(1).js')); ?>"></script>
    <script>
        window.Laravel = <?php echo json_encode([
                'csrfToken' => csrf_token(),
        ]); ?>
    </script>
</head>
<body>


<div class="container-div">
    <div class="menu-wrap">
        <nav class="menu-top">
            <div class="profile">
                <img src="<?php echo e(asset('img/user3.jpg')); ?>" alt="Sameh Bilal" width="42" height="42" />
                <span>Sameh Bilal</span>
            </div>
            <div class="icon-list">
                <a href="#"><i class="fa fa-fw fa-bell-o"></i> Notifications</a>
                <a href="my-lists"><i class="fa fa-pencil" aria-hidden="true"></i> My Lists</a>
                <a href="#" class=""><i class="fa fa-external-link" aria-hidden="true"></i> Log out</a>
            </div>
        </nav>
        <nav class="menu-side">
            <br>
            <a href="/"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
            <a href="#"><i class="fa fa-align-right" aria-hidden="true"></i> Categories</a>
            <a href="/about"><i class="fa fa-user-secret" aria-hidden="true"></i> About Us</a>
            <a href="#"><i class="fa fa-key" aria-hidden="true"></i> How it Works</a>
        </nav>
    </div>
    <button class="menu-button" id="open-button"></button>

    <div  class="content-wrap">
        <div  class="content">



            <div class="container">
                <!-- Top Navigation -->
                <!--<div class="codrops-top clearfix">
                    <a class="codrops-icon codrops-icon-prev" href="../../index.html"><span>Back home</span></a>
                    <span class="right"><a class="codrops-icon " href="../About%20Us/AboutUs.html"><span><i class="fa fa-user-secret" aria-hidden="true"></i> About us</span></a></span>
                </div>-->
                <section>
                    <form id="theForm" class="simform" autocomplete="off" role="form" method="POST" action="<?php echo e(url('/register')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="simform-inner">
                            <ol class="questions">
                                <li>
                                    <span><label for="q1">Full name?</label></span>
                                    <input id="q1" name="name" value="<?php echo e(old('name')); ?>" type="text"/>
                                </li>
                                <li>
                                    <span><label for="q2">Email</label></span>
                                    <input id="q2" name="email" value="<?php echo e(old('email')); ?>" type="email"/>
                                </li>
                                <li>
                                    <span><label for="q3">Password?</label></span>
                                    <input id="q3" name="password" type="password"/>
                                </li>
                                <li>
                                    <span><label for="q4">Password again</label></span>
                                    <input id="q4" name="password_confirmation" type="password"/>
                                </li>
                            </ol><!-- /questions -->
                            <button class="submit" type="submit">Send answers</button>
                            <div class="controls">
                                <button class="next"></button>
                                <div class="progress"></div>
							<span class="number">
								<span class="number-current"></span>
								<span class="number-total"></span>
							</span>
                                <span class="error-message"></span>
                            </div><!-- / controls -->
                        </div><!-- /simform-inner -->
                        <span class="final-message"></span>
                    </form><!-- /simform -->
                </section>
            </div><!-- /container -->
        </div>
    </div>
</div>
<script src="<?php echo e(asset('js/classie(1).js')); ?>"></script>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>
<script src="<?php echo e(asset('js/stepsForm.js')); ?>"></script>
<script>
    var theForm = document.getElementById( 'theForm' );

    new stepsForm( theForm, {
        onSubmit : function( form ) {
            // hide form
            classie.addClass( theForm.querySelector( '.simform-inner' ), 'hide' );

            /*
             form.submit()
             or
             AJAX request (maybe show loading indicator while we don't have an answer..)
             */

            // let's just simulate something...
            var messageEl = theForm.querySelector( '.final-message' );
            messageEl.innerHTML = 'Thank you! We\'ll be in touch.' + '<br><a href="/">Back home <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i></a>';
            classie.addClass( messageEl, 'show' );
        }
    } );
</script>
</body>
</html>