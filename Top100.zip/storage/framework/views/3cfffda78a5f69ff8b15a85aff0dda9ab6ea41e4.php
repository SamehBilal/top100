<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="description" content="top books">
    <meta name="keywords" content="book,books,كتاب,كتب,novel,novels,رواية,روايات">
    <meta name="author" content="Sameh Ramadan,Ahmed Elsamahy,Mohamed faramawy,mustafa hegazi,mustafa kamel,ahmed naser, abdallah khaled,amr yasser,mohamed eltabaey,sherif ezzat">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Top books</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/normalize.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fonts/font-awesome-4.2.0/css/font-awesome.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/menu_topside.css')); ?>" />
    <link href="<?php echo e(asset('css/application.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/toolkit.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/demobooks.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/tooltip-flip.css')); ?>" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
            <?php for($T=1;$T<101;$T++): ?>
            $('.rate<?php echo e($T); ?>').click(function(){
                $('.namein').val('<?php echo e($T); ?>');
            });
            <?php endfor; ?>
            <?php for($e=1;$e<11;$e++): ?>
           $('.sub<?php echo e($e); ?>').click(function(){
                $('#myform<?php echo e($e); ?>').submit();
            });
            $('.star<?php echo e($e); ?>').hover(function(){
                $('.star<?php echo e($e); ?>').removeClass( "fa-star-o" ).addClass( "fa-star" );
                $('.star<?php echo e($e-1); ?>').removeClass( "fa-star-o" ).addClass( "fa-star" );
                $('.star<?php echo e($e-2); ?>').removeClass( "fa-star-o" ).addClass( "fa-star" );
                $('.star<?php echo e($e-3); ?>').removeClass( "fa-star-o" ).addClass( "fa-star" );
                $('.star<?php echo e($e-4); ?>').removeClass( "fa-star-o" ).addClass( "fa-star" );
                $('.star<?php echo e($e-5); ?>').removeClass( "fa-star-o" ).addClass( "fa-star" );
                $('.star<?php echo e($e-6); ?>').removeClass( "fa-star-o" ).addClass( "fa-star" );
                $('.star<?php echo e($e-7); ?>').removeClass( "fa-star-o" ).addClass( "fa-star" );
                $('.star<?php echo e($e-8); ?>').removeClass( "fa-star-o" ).addClass( "fa-star" );
                $('.star<?php echo e($e-9); ?>').removeClass( "fa-star-o" ).addClass( "fa-star" );
            }).mouseleave(function(){
                $('.star<?php echo e($e); ?>').removeClass( "fa-star" ).addClass( "fa-star-o" );
                $('.star<?php echo e($e-1); ?>').removeClass( "fa-star" ).addClass( "fa-star-o" );
                $('.star<?php echo e($e-2); ?>').removeClass( "fa-star" ).addClass( "fa-star-o" );
                $('.star<?php echo e($e-3); ?>').removeClass( "fa-star" ).addClass( "fa-star-o" );
                $('.star<?php echo e($e-4); ?>').removeClass( "fa-star" ).addClass( "fa-star-o" );
                $('.star<?php echo e($e-5); ?>').removeClass( "fa-star" ).addClass( "fa-star-o" );
                $('.star<?php echo e($e-6); ?>').removeClass( "fa-star" ).addClass( "fa-star-o" );
                $('.star<?php echo e($e-7); ?>').removeClass( "fa-star" ).addClass( "fa-star-o" );
                $('.star<?php echo e($e-8); ?>').removeClass( "fa-star" ).addClass( "fa-star-o" );
                $('.star<?php echo e($e-9); ?>').removeClass( "fa-star" ).addClass( "fa-star-o" );
            });
            <?php endfor; ?>
             $('.stop-rate').click(function(){
                $('.rate').css('display','none');
                $('.rate-button').css('display','none');
            });
            $('.start-rate').click(function(){
                $('.rate').css('display','block');
                $('.rate-button').css('display','inline');
            })
        })
    </script>
</head>
<body>
<div class="container-div">
    <div class="menu-wrap">

        <nav class="menu-top">
            <div class="profile">

                <?php if(!Auth::guest()): ?>
                    <img src="<?php echo e(asset('img/top100.png')); ?>" alt="" width="42" height="42" />
                    <span style="font-size: large;font-weight: bold"><?php echo e(Auth::user()->name); ?></span>
                <?php endif; ?>

                <?php if(Auth::guest()): ?>
                    <img src="<?php echo e(asset('img/top100.png')); ?>" alt="" width="42" height="42" />
                    <span>Top 100</span>
                <?php endif; ?>
            </div>
            <?php if(!Auth::guest()): ?>
                <div class="icon-list">
                    <a href="/admin-panel">
                        <i class="fa fa-lock" aria-hidden="true"></i>
                        Admin Panel
                    </a>
                    
                    <a href="<?php echo e(url('/logout')); ?>"
                       onclick="event.preventDefault();
                             document.getElementById('logout-form').submit();">
                        <i class="fa fa-external-link" aria-hidden="true"></i>
                        Logout
                    </a>

                    <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                    </form>
                </div>
            <?php endif; ?>
        </nav>

        <nav class="menu-side">
            <br>
            <a href="/">
                <i class="fa fa-home" aria-hidden="true"></i>
                Home
            </a>
            <a href="/categories">
                <i class="fa fa-align-right" aria-hidden="true"></i>
                Categories
            </a>
            <a href="/about">
                <i class="fa fa-user-secret" aria-hidden="true"></i>
                About Us
            </a>
            <a href="/how-it-works">
                <i class="fa fa-key" aria-hidden="true"></i>
                How it Works
            </a>
        </nav>
    </div>

    <button class="menu-button" id="open-button">
        <img src="<?php echo e(asset('img/top100.png')); ?>" alt="" width="50px" height="50px">
    </button>
    <div  class="content-wrap">
        <div class="content">
            <div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-sm">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Rate</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">

                            <?php for($r=1;$r<11;$r++): ?>
                                <form id="myform<?php echo e($r); ?>" action="" method="get">
                                    <span class="sub<?php echo e($r); ?>" style="cursor: pointer;"><i class="star<?php echo e($r); ?> fa fa-star-o fa-2x" aria-hidden="true"></i><?php echo e($r); ?></span>
                                    <input type="hidden" value="<?php echo e($r); ?>" name="rate">
                                    <input type="hidden" value="1" name="numofrates">
                                    <input type="hidden" class="namein" name="position">
                                </form>
                                <?php endfor; ?>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
            <header class="codrops-header">
                <h1><i class="fa fa-book" aria-hidden="true"></i>
                    Books<span>The top 100 books in Egypt</span>
                </h1>
                <?php if(!Auth::guest()): ?>
                    <button class="btn btn-success start-rate">Start Rate</button>
                    <button class="btn btn-danger stop-rate">Stop Rate</button>
                <?php endif; ?>
            </header>
            <div class="container row">
                <div class="col-md-offset-2 col-md-10">
                    <img src="<?php echo e(asset('img/books3.png')); ?>" alt="" width="100%" height="100%">
                </div>
                <div class="dummy dummy-menu">
                    <ul>
                        <?php for($i=1;$i<11;$i++): ?>
                        <li id="num<?php echo e($i); ?>">
                            <a class="tooltip tooltip-effect-1" href="#">
                                <img src="../img/<?php echo e($i); ?>.png" alt="" width="30" height="30">
								<span class="tooltip-content">
									<span class="tooltip-front">
                                        <img src="../img/<?php echo e(DB::table('books')->where('position', '=', $i)->value('image_path')); ?>" alt="user4" width="60px" height="60px"/>
                                    </span>
									<span class="tooltip-back"><?php echo e(DB::table('books')->where('position', '=', $i)->value('name')); ?>

                                        <br>
                                    <span class=" rate-books">
                                        <i class="fa fa-star " aria-hidden="true"></i> <?php echo e(DB::table('books')->where('position', '=', $i)->value('average')); ?>

                                    </span><br>
                                        <span class="rate<?php echo e($i); ?> rate-books rate-button" data-toggle="modal" data-target=".bd-example-modal-sm">
                                            <i class="fa fa-star-o" aria-hidden="true"></i>
                                            rate
                                        </span>
                                    </span>
								</span>
                            </a>
                        </li>
                        <?php endfor; ?>
                    </ul>
                </div>
            </div>

            <div class="container p-t-md">
                <div class="row">
                    <div class="col-md-offset-2 col-md-8">
                        <div class="list-group m-b-md">
                            <ul class="list-group media-list media-list-stream">
                                <?php for($i=11;$i<101;$i++): ?>
                                    <li class="list-group-item media p-a">
                                        <div class="media-left">
                                            <span class="icon  num"><?php echo e($i); ?></span>
                                        </div>

                                        <div class="media-body">
                                            <small class="pull-right text-muted">
                                                

                                                <span class="rate rate<?php echo e($i); ?> rate-button" data-toggle="modal" data-target=".bd-example-modal-sm"><i class="fa fa-star-o fa-2x" aria-hidden="true"></i>rate</span>
                                                <span class="rating"><i class="fa fa-star fa-2x" aria-hidden="true"></i> </span>


                                            </small>
                                        <span class="heading">
                                            New Book
                                        </span>
                                        </div>
                                    </li>
                                <?php endfor; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/chart.js')); ?>"></script>
<script src="<?php echo e(asset('js/toolkit.js')); ?>"></script>
<script src="<?php echo e(asset('js/application.js')); ?>"></script>
<script src="<?php echo e(asset('js/classie.js')); ?>"></script>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>
</body>
</html>