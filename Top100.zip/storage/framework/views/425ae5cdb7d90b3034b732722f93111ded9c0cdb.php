<?php
$result = "";
$error = "";
if (isset($_GET['search'])) {
$url = file_get_contents("http://www.reddit.com/search.json?q=".$_GET['query']."&restrict_sr=on");
$array = json_decode($url, true);
//print_r($array);
    echo $array["data"];


}
?>
<!doctype html>
<html lang="en">
<head>

    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <title>
        Reddit App
    </title>

    <link rel="icon" href="<?php echo e(asset('img/Reddit-icon.png')); ?>" />

    <link href='https://fonts.googleapis.com/css?family=Lora:400,400italic|Work+Sans:300,400,500,600' rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" />


</head>
<body>

<div class="container">

    <h1>What's The Weather?</h1>

    <form method="get">
        <fieldset class="form-group">
            <label for="city">Enter the name of a city.</label>
            <input type="text" class="form-control" name="query" id="query" placeholder="Search Reddit" value = "">
        </fieldset>

        <button type="submit" class="btn btn-primary" name="search">Search</button>
    </form>

</div>
<script src="<?php echo e(asset('js/jquery-3.1.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

<script>

</script>


</body>
</html>