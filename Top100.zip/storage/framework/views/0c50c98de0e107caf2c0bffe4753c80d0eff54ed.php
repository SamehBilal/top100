
<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Aham 100 | Home Page</title>
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="author" content="aham 100" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="shortcut icon" href="">


    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/normalize.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fonts/font-awesome-4.2.0/css/font-awesome.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/menu_topside.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/menu.css')); ?>" />
    <link href="/css/app.css" rel="stylesheet">
    <!--[if IE]>
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]--><script>document.documentElement.className = 'js';</script>
    <script>
        window.Laravel = <?php echo json_encode([
                'csrfToken' => csrf_token(),
        ]); ?>
    </script>
</head>
<body>


<div class="container-div">
    <div class="menu-wrap">

        <nav class="menu-top">
            <div class="profile">
                <img src="<?php echo e(asset('img/top100.png')); ?>" alt="" width="42" height="42" />
                <span>Top 100</span>
            </div>
            <?php if(!Auth::guest()): ?>
            <div class="icon-list">
                <a href="/admin-panel"><i class="fa fa-lock" aria-hidden="true"></i> Admin Panel</a>
                <a href="/my-lists"><i class="fa fa-pencil" aria-hidden="true"></i> My Lists</a>
                <a href="<?php echo e(url('/logout')); ?>"
                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                    <i class="fa fa-external-link" aria-hidden="true"></i>
                    Logout
                </a>

                <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                    <?php echo e(csrf_field()); ?>

                </form>
            </div>
            <?php endif; ?>
        </nav>

        <nav class="menu-side">
            <br>
            <a href="/"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
            <a href="/categories"><i class="fa fa-align-right" aria-hidden="true"></i> Categories</a>
            <a href="/about"><i class="fa fa-user-secret" aria-hidden="true"></i> About Us</a>
            <a href="/how-it-works"><i class="fa fa-key" aria-hidden="true"></i> How it Works</a>
        </nav>
    </div>
    <button class="menu-button" id="open-button"><img src="<?php echo e(asset('img/top100.png')); ?>" alt="" width="50px" height="50px"></button>

    <div  class="content-wrap">
        <div id="resizeSlider" class="content">


            

            <div id="morphsearch" class="morphsearch">
                <form class="morphsearch-form">
                    <input class="morphsearch-input" type="search" placeholder="Search..."/>
                    <button class="morphsearch-submit" type="submit">Search</button>
                </form>
                <div class="morphsearch-content">
                    <div class="dummy-column">
                        <h2>Suggested</h2>
                        <a class="dummy-media-object" href="categories/cafes">
                            <i class="fa fa-coffee" aria-hidden="true"></i>
                            <h3>Cafés</h3>
                        </a>
                        <a class="dummy-media-object" href="categories/movies">
                            <i class="fa fa-film" aria-hidden="true"></i>
                            <h3>Movies</h3>
                        </a>
                        <a class="dummy-media-object" href="http://www.twitter.com/peterfinlan">
                            <i class="fa fa-music" aria-hidden="true"></i>
                            <h3>Music</h3>
                        </a>
                        <a class="dummy-media-object" href="http://www.twitter.com/pcridesagain">
                            <i class="fa fa-tablet" aria-hidden="true"></i>
                            <h3>Mobiles</h3>
                        </a>
                        <a class="dummy-media-object" href="https://twitter.com/twholman">
                            <img class="round" src="http://0.gravatar.com/avatar/cb947f0ebdde8d0f973741b366a51ed6?s=50&d=identicon&r=G" alt="Tim Holman"/>
                            <h3>Tim Holman</h3>
                        </a>
                        <a class="dummy-media-object" href="https://twitter.com/shaund0na">
                            <img class="round" src="http://1.gravatar.com/avatar/9bc7250110c667cd35c0826059b81b75?s=50&d=identicon&r=G" alt="Shaun Dona"/>
                            <h3>Shaun Dona</h3>
                        </a>
                    </div>
                    <div class="dummy-column">
                        <h2>Popular</h2>
                        <a class="dummy-media-object" href="http://tympanus.net/codrops/2014/08/05/page-preloading-effect/">
                            <img src="img/thumbs/PagePreloadingEffect.png" alt="PagePreloadingEffect"/>
                            <h3>Page Preloading Effect</h3>
                        </a>
                        <a class="dummy-media-object" href="http://tympanus.net/codrops/2014/05/28/arrow-navigation-styles/">
                            <img src="img/thumbs/ArrowNavigationStyles.png" alt="ArrowNavigationStyles"/>
                            <h3>Arrow Navigation Styles</h3>
                        </a>
                        <a class="dummy-media-object" href="http://tympanus.net/codrops/2014/06/19/ideas-for-subtle-hover-effects/">
                            <img src="img/thumbs/HoverEffectsIdeasNew.png" alt="HoverEffectsIdeasNew"/>
                            <h3>Ideas for Subtle Hover Effects</h3>
                        </a>
                        <a class="dummy-media-object" href="http://tympanus.net/codrops/2014/07/14/freebie-halcyon-days-one-page-website-template/">
                            <img src="img/thumbs/FreebieHalcyonDays.png" alt="FreebieHalcyonDays"/>
                            <h3>Halcyon Days Template</h3>
                        </a>
                        <a class="dummy-media-object" href="http://tympanus.net/codrops/2014/05/22/inspiration-for-article-intro-effects/">
                            <img src="img/thumbs/ArticleIntroEffects.png" alt="ArticleIntroEffects"/>
                            <h3>Inspiration for Article Intro Effects</h3>
                        </a>
                        <a class="dummy-media-object" href="http://tympanus.net/codrops/2014/06/26/draggable-dual-view-slideshow/">
                            <img src="img/thumbs/DraggableDualViewSlideshow.png" alt="DraggableDualViewSlideshow"/>
                            <h3>Draggable Dual-View Slideshow</h3>
                        </a>
                    </div>
                    <div class="dummy-column">
                        <h2>Recent</h2>
                        <a class="dummy-media-object" href="http://tympanus.net/codrops/2014/10/07/tooltip-styles-inspiration/">
                            <img src="img/thumbs/TooltipStylesInspiration.png" alt="TooltipStylesInspiration"/>
                            <h3>Tooltip Styles Inspiration</h3>
                        </a>
                        <a class="dummy-media-object" href="http://tympanus.net/codrops/2014/09/23/animated-background-headers/">
                            <img src="img/thumbs/AnimatedHeaderBackgrounds.png" alt="AnimatedHeaderBackgrounds"/>
                            <h3>Animated Background Headers</h3>
                        </a>
                        <a class="dummy-media-object" href="http://tympanus.net/codrops/2014/09/16/off-canvas-menu-effects/">
                            <img src="img/thumbs/OffCanvas.png" alt="OffCanvas"/>
                            <h3>Off-Canvas Menu Effects</h3>
                        </a>
                        <a class="dummy-media-object" href="http://tympanus.net/codrops/2014/09/02/tab-styles-inspiration/">
                            <img src="img/thumbs/TabStyles.png" alt="TabStyles"/>
                            <h3>Tab Styles Inspiration</h3>
                        </a>
                        <a class="dummy-media-object" href="http://tympanus.net/codrops/2014/08/19/making-svgs-responsive-with-css/">
                            <img src="img/thumbs/ResponsiveSVGs.png" alt="ResponsiveSVGs"/>
                            <h3>Make SVGs Responsive with CSS</h3>
                        </a>
                        <a class="dummy-media-object" href="http://tympanus.net/codrops/2014/07/23/notification-styles-inspiration/">
                            <img src="img/thumbs/NotificationStyles.png" alt="NotificationStyles"/>
                            <h3>Notification Styles Inspiration</h3>
                        </a>
                    </div>
                </div>
                <span class="morphsearch-close"></span>
                <div class="overlay"></div>
                <!-- /search -->
            </div>

           




        <div class="dummy-fixed">
            <?php if(Auth::guest()): ?>
            <a id="sign-up" href="/register">
                <img class="down" src="<?php echo e(asset('img/new user.png')); ?>" alt="" width="70px" height="90px">
            </a>
            <div class="checkout">
                <a class="checkout__button" href=""><!-- Fallback location -->
						<span class="checkout__text">
							<span class=" checkout__text-inner checkout__initial-text">Log In</span>
						</span>
                </a>
                <div class="checkout__order">
                    <div class="checkout__order-inner">
                        <div class="checkout__summary input-container">

                            <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/login')); ?>">
                                <?php echo e(csrf_field()); ?>


                                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                    <label for="email" class="col-md-4 control-label">E-Mail</label>

                                    <div class="col-md-6">
                                        <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                        <?php if($errors->has('email')): ?>
                                            <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                    <label for="password" class="col-md-4 control-label">Password</label>

                                    <div class="col-md-6">
                                        <input id="password" type="password" class="form-control" name="password" required>

                                        <?php if($errors->has('password')): ?>
                                            <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-4">
                                        <div class="checkbox">
                                            <label>
                                                <input type="checkbox" name="remember"> Remember Me
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-md-8 col-md-offset-4">
                                        <button type="submit" class="btn btn-primary">
                                            Login
                                        </button>

                                        <a class="btn btn-link" href="<?php echo e(url('/password/reset')); ?>">
                                            Forgot Your Password?
                                        </a>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <button class="checkout__close checkout__cancel"><i class="icon fa fa-fw fa-close"></i>Close</button>
                    </div><!-- /checkout__order-inner -->
                </div><!-- /checkout__order -->
            </div><!-- /checkout -->
            <?php endif; ?>
            <a href=""><div class="checkout__count">
                    <i class="fa fa-youtube-play" aria-hidden="true"></i>
                </div></a>
            <a href=""><div class=" one">
                    <i class="fa fa-instagram" aria-hidden="true"></i>
                </div></a>
            <a href=""><div class=" two">
                    <i class="fa fa-twitter" aria-hidden="true"></i>
                </div></a>
            <a href="">
                <div class=" three">
                    <i class="fa fa-facebook" aria-hidden="true"></i>
                </div>
            </a>
        </div>
        </div>
    </div><!-- /content-wrap -->

</div><!-- /container -->
<script src="<?php echo e(asset('js/classie.js')); ?>"></script>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>
<script src="<?php echo e(asset('js/demo2.js')); ?>"></script>
<script src="/js/app.js"></script>
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-3.1.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/clipboard.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/resize-slider-min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/example.js')); ?>"></script>
<script type="text/javascript">

    var _gaq = _gaq || [];
    _gaq.push(['_setAccount', 'UA-36251023-1']);
    _gaq.push(['_setDomainName', 'jqueryscript.net']);
    _gaq.push(['_trackPageview']);

    (function() {
        var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
    })();

</script>

<script src="<?php echo e(asset('js/classiee.js')); ?>"></script>
<script>
    (function() {
        var dummy = document.getElementById('dummy-grid');
        [].slice.call( document.querySelectorAll( '.checkout' ) ).forEach( function( el ) {
            var openCtrl = el.querySelector( '.checkout__button' ),
                    closeCtrl = el.querySelector( '.checkout__cancel' );

            openCtrl.addEventListener( 'click', function(ev) {
                ev.preventDefault();
                classie.add( el, 'checkout--active' );
                classie.add( dummy, 'dummy-grid--highlight' );
            } );

            closeCtrl.addEventListener( 'click', function() {
                classie.remove( el, 'checkout--active' );
                classie.remove( dummy, 'dummy-grid--highlight' );
            } );
        } );
    })();
</script>


<script src="<?php echo e(asset('js/classieee.js')); ?>"></script>
<script>
    (function() {
        var morphSearch = document.getElementById( 'morphsearch' ),
                input = morphSearch.querySelector( 'input.morphsearch-input' ),
                ctrlClose = morphSearch.querySelector( 'span.morphsearch-close' ),
                isOpen = isAnimating = false,
        // show/hide search area
                toggleSearch = function(evt) {
                    // return if open and the input gets focused
                    if( evt.type.toLowerCase() === 'focus' && isOpen ) return false;

                    var offsets = morphsearch.getBoundingClientRect();
                    if( isOpen ) {
                        classie.remove( morphSearch, 'open' );

                        // trick to hide input text once the search overlay closes
                        // todo: hardcoded times, should be done after transition ends
                        if( input.value !== '' ) {
                            setTimeout(function() {
                                classie.add( morphSearch, 'hideInput' );
                                setTimeout(function() {
                                    classie.remove( morphSearch, 'hideInput' );
                                    input.value = '';
                                }, 300 );
                            }, 500);
                        }

                        input.blur();
                    }
                    else {
                        classie.add( morphSearch, 'open' );
                    }
                    isOpen = !isOpen;
                };

        // events
        input.addEventListener( 'focus', toggleSearch );
        ctrlClose.addEventListener( 'click', toggleSearch );
        // esc key closes search overlay
        // keyboard navigation events
        document.addEventListener( 'keydown', function( ev ) {
            var keyCode = ev.keyCode || ev.which;
            if( keyCode === 27 && isOpen ) {
                toggleSearch(ev);
            }
        } );


        /***** for demo purposes only: don't allow to submit the form *****/
        morphSearch.querySelector( 'button[type="submit"]' ).addEventListener( 'click', function(ev) { ev.preventDefault(); } );
    })();

    $(document).ready(function(){
        $('#categoriesController').click(function() {
            $('#categories').toggle();
        })
    });
</script>


</body>
</html>