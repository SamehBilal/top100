<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Drag and Drop Interaction Ideas | Icons</title>
    <meta name="description" content="Inspiration for drag and drop interactions for the modern UI" />
    <meta name="keywords" content="drag and drop, interaction, inspiration, web design, ui" />
    <meta name="author" content="Codrops" />
    <link rel="shortcut icon" href="../favicon.ico">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/normalize.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fonts/font-awesome-4.2.0/css/font-awesome.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/democafes.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/menu_topside.css')); ?>" />
    <link href="<?php echo e(asset('css/application.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/toolkit.css')); ?>" rel="stylesheet">

    <script src="<?php echo e(asset('js/modernizr.custom.js')); ?>"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
            <?php for($T=1;$T<101;$T++): ?>
            $('.rate<?php echo e($T); ?>').click(function(){
                $('.namein').val('<?php echo e($T); ?>');
            });
            <?php endfor; ?>
        <?php for($e=1;$e<11;$e++): ?>
       $('.sub<?php echo e($e); ?>').click(function(){
                $('#myform<?php echo e($e); ?>').submit();
            });
            $('.star<?php echo e($e); ?>').hover(function(){
                $('.star<?php echo e($e); ?>').removeClass( "fa-star-o" ).addClass( "fa-star" );
                $('.star<?php echo e($e-1); ?>').removeClass( "fa-star-o" ).addClass( "fa-star" );
                $('.star<?php echo e($e-2); ?>').removeClass( "fa-star-o" ).addClass( "fa-star" );
                $('.star<?php echo e($e-3); ?>').removeClass( "fa-star-o" ).addClass( "fa-star" );
                $('.star<?php echo e($e-4); ?>').removeClass( "fa-star-o" ).addClass( "fa-star" );
                $('.star<?php echo e($e-5); ?>').removeClass( "fa-star-o" ).addClass( "fa-star" );
                $('.star<?php echo e($e-6); ?>').removeClass( "fa-star-o" ).addClass( "fa-star" );
                $('.star<?php echo e($e-7); ?>').removeClass( "fa-star-o" ).addClass( "fa-star" );
                $('.star<?php echo e($e-8); ?>').removeClass( "fa-star-o" ).addClass( "fa-star" );
                $('.star<?php echo e($e-9); ?>').removeClass( "fa-star-o" ).addClass( "fa-star" );
            }).mouseleave(function(){
                $('.star<?php echo e($e); ?>').removeClass( "fa-star" ).addClass( "fa-star-o" );
                $('.star<?php echo e($e-1); ?>').removeClass( "fa-star" ).addClass( "fa-star-o" );
                $('.star<?php echo e($e-2); ?>').removeClass( "fa-star" ).addClass( "fa-star-o" );
                $('.star<?php echo e($e-3); ?>').removeClass( "fa-star" ).addClass( "fa-star-o" );
                $('.star<?php echo e($e-4); ?>').removeClass( "fa-star" ).addClass( "fa-star-o" );
                $('.star<?php echo e($e-5); ?>').removeClass( "fa-star" ).addClass( "fa-star-o" );
                $('.star<?php echo e($e-6); ?>').removeClass( "fa-star" ).addClass( "fa-star-o" );
                $('.star<?php echo e($e-7); ?>').removeClass( "fa-star" ).addClass( "fa-star-o" );
                $('.star<?php echo e($e-8); ?>').removeClass( "fa-star" ).addClass( "fa-star-o" );
                $('.star<?php echo e($e-9); ?>').removeClass( "fa-star" ).addClass( "fa-star-o" );
            });
            <?php endfor; ?>
             $('.stop-rate').click(function(){
                $('.rate').css('display','none');
            });
            $('.start-rate').click(function(){
                $('.rate').css('display','block');
            })
        })
    </script>
</head>
<body class="skin-4">

<div class="container-div">
    <div class="menu-wrap">

        <nav class="menu-top">
            <div class="profile">
                <img src="<?php echo e(asset('img/top100.png')); ?>" alt="" width="42" height="42" />
                <span>Top 100</span>
            </div>
            <?php if(!Auth::guest()): ?>
                <div class="icon-list">
                    <a href="#"><i class="fa fa-fw fa-bell-o"></i> Notifications</a>
                    <a href="my-lists"><i class="fa fa-pencil" aria-hidden="true"></i> My Lists</a>
                    <a href="<?php echo e(url('/logout')); ?>"
                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                        <i class="fa fa-external-link" aria-hidden="true"></i>
                        Logout
                    </a>

                    <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>
                </div>
            <?php endif; ?>
        </nav>

        <nav class="menu-side">
            <br>
            <a href="/"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
            <a href="/categories"><i class="fa fa-align-right" aria-hidden="true"></i> Categories</a>
            <a href="/about"><i class="fa fa-user-secret" aria-hidden="true"></i> About Us</a>
            <a href="/how-it-works"><i class="fa fa-key" aria-hidden="true"></i> How it Works</a>
        </nav>
    </div>
    <button class="menu-button" id="open-button"><img src="<?php echo e(asset('img/top100.png')); ?>" alt="" width="50px" height="50px"></button>

    <div  class="content-wrap">
        <div class="content">
            <div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-sm">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Rate</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">

                            <?php for($r=1;$r<11;$r++): ?>
                                <form id="myform<?php echo e($r); ?>" action="" method="get">
                                    <span class="sub<?php echo e($r); ?>" style="cursor: pointer;"><i class="star<?php echo e($r); ?> fa fa-star-o fa-2x" aria-hidden="true"></i><?php echo e($r); ?></span>
                                    <input type="hidden" value="<?php echo e($r); ?>" name="rate">
                                    <input type="hidden" value="1" name="numofrates">
                                    <input type="hidden" class="namein" name="position">
                                </form>
                            <?php endfor; ?>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
<div class="container">
    <div id="top-10">
        <header class="codrops-header">
            <h1>
                <i class="fa fa-coffee" aria-hidden="true"></i>
                Caf&eacute;s <span>The top 100 caf&eacute;s in Egypt</span>
            </h1>
            <?php if(!Auth::guest()): ?>
                <button class="btn btn-success start-rate">Start Rate</button>
                <button class="btn btn-danger stop-rate">Stop Rate</button>
            <?php endif; ?>
        </header>

        <div class="dummy dummy-image">
            <div class="dummy-pois">
                <div class="tooltip tooltip-west">
                    <span class="tooltip-item"></span>
                    <span class="tooltip-content">
                        New cafe
                        <br>
                    <span class="rate rate1 rate-button" data-toggle="modal" data-target=".bd-example-modal-sm">
                        <i class="fa fa-star-o fa-2x" aria-hidden="true"></i>
                        rate
                    </span>
                        <span class="rating">
                            <i class="fa fa-star fa-2x" aria-hidden="true"></i>
                            8.3
                        </span>
                    </span>
                </div>
                <div class="tooltip tooltip-east">
                    <span class="tooltip-item"></span>
                    <span class="tooltip-content">New cafe
                    <br>
                    <span class="rate rate2 rate-button" data-toggle="modal" data-target=".bd-example-modal-sm"><i class="fa fa-star-o fa-2x" aria-hidden="true"></i>rate</span>
                                            <span class="rating"><i class="fa fa-star fa-2x" aria-hidden="true"></i> 8.3</span>
                    </span>
                </div>
                <div class="tooltip tooltip-east">
                    <span class="tooltip-item"></span>
                    <span class="tooltip-content">New cafe
                    <br>
                    <span class="rate rate3 rate-button" data-toggle="modal" data-target=".bd-example-modal-sm"><i class="fa fa-star-o fa-2x" aria-hidden="true"></i>rate</span>
                                            <span class="rating"><i class="fa fa-star fa-2x" aria-hidden="true"></i> 8.3</span>
                    </span>
                </div>
                <div class="tooltip tooltip-east">
                    <span class="tooltip-item"></span>
                    <span class="tooltip-content">New cafe
                    <br>
                    <span class="rate rate4 rate-button" data-toggle="modal" data-target=".bd-example-modal-sm"><i class="fa fa-star-o fa-2x" aria-hidden="true"></i>rate</span>
                                            <span class="rating"><i class="fa fa-star fa-2x" aria-hidden="true"></i> 8.3</span>
                    </span>
                </div>
                <div class="tooltip tooltip-west">
                    <span class="tooltip-item"></span>
                    <span class="tooltip-content">New cafe
                        <br>
                    <span class="rate rate5 rate-button" data-toggle="modal" data-target=".bd-example-modal-sm"><i class="fa fa-star-o fa-2x" aria-hidden="true"></i>rate</span>
                                            <span class="rating"><i class="fa fa-star fa-2x" aria-hidden="true"></i> 8.3</span>
                    </span>
                </div>
                <div class="tooltip tooltip-west">
                    <span class="tooltip-item"></span>
                    <span class="tooltip-content">New cafe
                    <br>
                    <span class="rate rate6 rate-button" data-toggle="modal" data-target=".bd-example-modal-sm"><i class="fa fa-star-o fa-2x" aria-hidden="true"></i>rate</span>
                                            <span class="rating"><i class="fa fa-star fa-2x" aria-hidden="true"></i> 8.3</span>
                    </span>
                </div>
                <div class="tooltip tooltip-east">
                    <span class="tooltip-item"></span>
                    <span class="tooltip-content">New cafe
                    <br>
                    <span class="rate rate7 rate-button" data-toggle="modal" data-target=".bd-example-modal-sm"><i class="fa fa-star-o fa-2x" aria-hidden="true"></i>rate</span>
                                            <span class="rating"><i class="fa fa-star fa-2x" aria-hidden="true"></i> 8.3</span>
                    </span>
                </div>
                <div class="tooltip tooltip-east">
                    <span class="tooltip-item"></span>
                    <span class="tooltip-content">New cafe
                    <br>
                    <span class="rate rate8 rate-button" data-toggle="modal" data-target=".bd-example-modal-sm"><i class="fa fa-star-o fa-2x" aria-hidden="true"></i>rate</span>
                                            <span class="rating"><i class="fa fa-star fa-2x" aria-hidden="true"></i> 8.3</span>
                    </span>
                </div>
                <div class="tooltip tooltip-east">
                    <span class="tooltip-item"></span>
                    <span class="tooltip-content">New cafe
                    <br>
                    <span class="rate rate9 rate-button" data-toggle="modal" data-target=".bd-example-modal-sm"><i class="fa fa-star-o fa-2x" aria-hidden="true"></i>rate</span>
                                            <span class="rating"><i class="fa fa-star fa-2x" aria-hidden="true"></i> 8.3</span>
                    </span>
                </div>
                <div class="tooltip tooltip-east">
                    <span class="tooltip-item"></span>
                    <span class="tooltip-content">New cafe
                    <br>
                    <span class="rate rate10 rate-button" data-toggle="modal" data-target=".bd-example-modal-sm"><i class="fa fa-star-o fa-2x" aria-hidden="true"></i>rate</span>
                                            <span class="rating"><i class="fa fa-star fa-2x" aria-hidden="true"></i> 8.3</span>
                    </span>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="container p-t-md">
            <div class="row">
                <div class="col-md-offset-2 col-md-8">
                    <div class="list-group m-b-md">
                        <ul class="list-group media-list media-list-stream">
                            <?php for($i=11;$i<101;$i++): ?>
                                <li class="list-group-item media p-a">
                                    <div class="media-left">
                                        <span class="icon  num"><?php echo e($i); ?></span>
                                    </div>

                                    <div class="media-body">
                                        <small class="pull-right text-muted">
                                            

                                            <span class="rate rate<?php echo e($i); ?> rate-button" data-toggle="modal" data-target=".bd-example-modal-sm"><i class="fa fa-star-o fa-2x" aria-hidden="true"></i>rate</span>
                                            <span class="rating"><i class="fa fa-star fa-2x" aria-hidden="true"></i> 8.3</span>


                                        </small>
                                        <span class="heading">
                                            New café
                                        </span>
                                    </div>
                                </li>
                            <?php endfor; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- Related demos -->


</div><!-- /container -->

</div>
</div>
</div>
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/chart.js')); ?>"></script>
<script src="<?php echo e(asset('js/toolkit.js')); ?>"></script>
<script src="<?php echo e(asset('js/application.js')); ?>"></script>
<script src="<?php echo e(asset('js/classie.js')); ?>"></script>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-3.1.1.min.js')); ?>"></script>
<script src="">
    $(document).ready(function(){
        $('.rate').click(function(){
           $('.rating').css('display','none');
        })
    })
</script>
</body>
</html>
