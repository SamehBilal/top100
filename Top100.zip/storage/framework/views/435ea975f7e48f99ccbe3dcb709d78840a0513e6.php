<!doctype html>
<html lang="en">
    <head>

            <meta charset="utf-8" />
            <meta http-equiv="X-UA-Compatible" content="IE=edge" />
            <meta name="viewport" content="width=device-width, initial-scale=1" />

            <title>
                Reddit App
            </title>

            <link rel="icon" href="<?php echo e(asset('img/Reddit-icon.png')); ?>" />

            <link href='https://fonts.googleapis.com/css?family=Lora:400,400italic|Work+Sans:300,400,500,600' rel='stylesheet' type='text/css' />
            <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fonts/font-awesome-4.2.0/css/font-awesome.min.css')); ?>" />
            <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" />
            <link rel="stylesheet" href="<?php echo e(asset('css/Style.css')); ?>" />

    </head>
    <body>

    <div class="container">

        <h1><i class="fa fa-camera" aria-hidden="true"></i> Search Reddit</h1>

        <form action="#" method="get">
            <fieldset class="form-group">
                <label for="city">Enter the name of a city.</label>
                <input type="text" class="form-control" name="query" id="query" placeholder="Search Reddit....." value = "<?= isset($_GET['search'])?$_GET['query']:'' ?>">
            </fieldset>

            <button type="submit" id="search" class="btn btn-primary" name="search">Search</button>
        </form>

        <div id="result">


            <?php if(isset($_GET['search'])): ?>
                <?php
                $url = file_get_contents("http://www.reddit.com/search.json?q=".$_GET['query']."&restrict_sr=on&sort=relevance");
                $array = json_decode($url, true);
                ?>
                <?php if(!array_key_exists(0,$array['data']['children'])): ?>
                    <h6 class="alert alert-danger">Couldn't find any results, Please try again with something more specific.</h6>
                <?php endif; ?>
                <?php for($i=0;$i<count($array['data']['children']);$i++): ?>
                    <?php if(array_key_exists('preview',$array['data']['children'][$i]['data'])): ?>
                        <?php if(array_key_exists('1',$array['data']['children'][$i]['data']['preview']['images'][0]['resolutions'])): ?>
                            <img src="<?php echo e($result=$array['data']['children'][$i]['data']['preview']['images'][0]['resolutions'][1]['url']); ?>" alt="">
                        <?php endif; ?>
                    <?php elseif(array_key_exists('preview',$array['data']['children'][$i]['data'])): ?>
                        <img src="<?php echo e($result=$array['data']['children'][$i]['data']['preview']['images'][0]['source']['url']); ?>" alt="">
                    <?php endif; ?>
                <?php endfor; ?>

            <?php endif; ?>



        </div>

    </div>
    <script src="<?php echo e(asset('js/jquery-3.1.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

    <script>

    </script>


    </body>
</html>