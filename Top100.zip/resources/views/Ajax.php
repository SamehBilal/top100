<?php
$Input = htmlspecialchars($_GET['input']);
echo $Input;
?>